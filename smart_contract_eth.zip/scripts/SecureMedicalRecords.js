const { ethers } = require("ethers");
const { create } = require('ipfs-http-client');
const crypto = require('crypto');

const IPFS_CONFIG = {
    PEER_ID: "12D3KooWGCPaCPuRQpWp6twyDyo5w9D8ChPVCR31jX5W9hrM3mJH",
    PUBLIC_KEY: "CAESIF7KfL3W4fHIIIUyI3va6T0jH1L9FwxNraXDm4dSgv5K"
};

const ipfs = create({
    host: 'ipfs.infura.io',
    port: 5001,
    protocol: 'https',
    headers: {
        'X-IPFS-PEER-ID': IPFS_CONFIG.PEER_ID,
        'X-IPFS-PUBKEY': IPFS_CONFIG.PUBLIC_KEY
    }
});

// RSA Encryption using your public key
function encryptData(data) {
    const publicKey = crypto.createPublicKey({
        key: Buffer.from(IPFS_CONFIG.PUBLIC_KEY, 'base64'),
        type: 'spki',
        format: 'der'
    });
    
    return crypto.publicEncrypt({
        key: publicKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256'
    }, Buffer.from(data)).toString('base64');
}

async function main() {
    // 1. Load CSV from your IPFS node
    const CSV_CID = 'YOUR_CSV_CID_HERE'; // Replace with your actual CID
    const { data } = await ipfs.cat(CSV_CID);
    const csvContent = data.toString();

    // 2. Deploy Contract
    const MedicalRecords = await ethers.getContractFactory("SecureMedicalRecords");
    const contract = await MedicalRecords.deploy();
    await contract.deployed();

    // 3. Verify IPFS Configuration
    const [contractPeerId, contractPubKey] = await contract.getIPFSConfig();
    console.log(`Contract connected to IPFS Node: ${contractPeerId}`);

    // 4. Prepare Accounts
    const [admin, doctor, patient] = await ethers.getSigners();
    
    // 5. Process Records
    const records = csvContent.split('\n').slice(1);
    for (const [index, record] of records.entries()) {
        const [recency, frequency, monetary, time, donated] = record.split(',');

        // Generate Patient ID
        const patientId = ethers.utils.keccak256(
            ethers.utils.defaultAbiCoder.encode(
                ['uint', 'uint', 'uint', 'uint', 'bool'],
                [recency, frequency, monetary, time, donated.trim() === '1']
            )
        );

        // Encrypt and Store
        const encryptedData = encryptData(JSON.stringify({
            recency, frequency, monetary, time, donated
        }));
        
        const { cid } = await ipfs.add(encryptedData);
        
        // Assign roles and store CID
        await contract.connect(admin).assignRole(2, doctor.address, patientId);
        await contract.connect(doctor).addEncryptedRecord(patientId, cid.toString());

        console.log(`Processed record ${index + 1}/${records.length}`);
    }

    console.log("All records processed successfully!");
    console.log(`Contract address: ${contract.address}`);
}

main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error("Execution error:", error);
        process.exit(1);
    });